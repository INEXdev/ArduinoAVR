#ifndef _ANALOG_H_
#define _ANALOG_H_
#include <WProgram.h>
#define knob() analog(7)
unsigned int analog(char ch)
{
 analogRead(ch);
 return(analogRead(ch));         
}

#endif
