//------------------------------------------------------------------------------------------------//
// Program	: Library for gennerate sound   
// Description 	: Library for gennerate easy sound at PWM3 pin
// Frequency	: Crytal 16 MHz  
// Filename	: sound.h
// C compiler	: Wirring
//------------------------------------------------------------------------------------------------//
#ifndef _SOUND_H_
#define _SOUND_H_
#include <WProgram.h>
#include <in_out.h>
#include <sleep.h>
void delay_sound(unsigned int ms)
{
	unsigned int i,j;
	for(i=0;i<ms;i++)
    delay_us(73);
}
void sound(int freq,unsigned int time)
{
	int dt=0,m=0;	// Keep value and 
    dt = 5000/freq;   	// Keep active logic delay
	time = (5*time)/dt;	// Keep counter for generate sound
	for(m=0;m<time;m++) // Loop for generate sound(Toggle logic P0.12)   
	{
        out(14,1);
		delay_sound(dt);	// Delay for sound	
        out(14,0);
		delay_sound(dt);	// Delay for sound
	}		
}
//------------------------------------------------------------------------------------------------//
//---------------------------- Function generate sound beep default ------------------------------//
//------------------------------------------------------------------------------------------------//
void beep()
{
	sound(500,100);	// Generate sound default frequency at 500 Hz,0.1 secound
}

#endif



